package com.mrdu.tests;

import java.util.Random;

import com.mrdu.R;
import com.mrdu.TestActivity;
import com.mrdu.bean.QuestionBean;
import com.mrdu.bean.TestID;

import android.app.Fragment;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONException;

public class StroopFormFragment extends Fragment implements OnClickListener {
	private ImageView photo;
	private Questionare qn;
	private Button answerButton1;
	private Button answerButton2;
	private Button answerButton3;
	private TextView disturb;
	private Rect disRect;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// [1]通过打气筒把一个布局转换成view对象
		View view = inflater.inflate(R.layout.fragment_stroop, container,false);
		photo = (ImageView) view.findViewById(R.id.iv_photo);
		answerButton1 = (Button) view.findViewById(R.id.pre_quest);
		answerButton2 = (Button) view.findViewById(R.id.next_quest);
		answerButton3 = (Button) view.findViewById(R.id.button3);
		answerButton1.setOnClickListener(this);
		answerButton2.setOnClickListener(this);
		answerButton3.setOnClickListener(this);
		disturb = (TextView) view.findViewById(R.id.textViewDisturb);
		qn = new Questionare(TestID.STROOP);
		qn.next();
		setQuestion(qn.getQuestion());

		return view;
	}

	private void setQuestion(QuestionBean qb) {
		String src = qb.question;
		String type = "drawable";
		String packge = "com.mrdu";
		int rid = getResources().getIdentifier(src, type, packge);
		photo.setImageResource(rid);		
		disturb.setTextSize(TypedValue.COMPLEX_UNIT_SP, 100);
		// 获取图片宽高
		Bitmap bitmap = BitmapFactory.decodeResource(this.getResources(),rid);
		int ww = bitmap.getWidth();
		int wh = bitmap.getHeight();
		Random r = new Random();
		int did = r.nextInt(5);
		switch(did){
			case 0:
				disturb.setText("高兴");
				break;
			case 1:
				disturb.setText("悲伤");
				break;
			case 2:
				disturb.setText("恐惧");
				break;
			case 3:
				disturb.setText("厌恶");
				break;
			case 4:
				disturb.setText("愤怒");
				break;
			case 5:
				disturb.setText("中性");
				break;
		}
	}

	@Override
	public void onClick(View v) {
		TestActivity activity = (TestActivity) this.getActivity();
		switch (v.getId()) {
		case R.id.pre_quest:
			qn.doAnswer(1);
			break;
		case R.id.next_quest:
			qn.doAnswer(2);
			break;
		case R.id.button3:
			qn.doAnswer(3);
			break;
		}
		if (qn.next()) {
			setQuestion(qn.getQuestion());
		} else {
//			try {
//				activity.onAnswer(qn.getScore(), TestID.STROOP);
//			} catch (JSONException e) {
//				e.printStackTrace();
//			}
		}
	}
}
