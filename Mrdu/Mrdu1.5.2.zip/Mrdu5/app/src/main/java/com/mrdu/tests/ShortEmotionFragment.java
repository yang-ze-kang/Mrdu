package com.mrdu.tests;

import com.mrdu.R;
import com.mrdu.TestActivity;
import com.mrdu.bean.QuestionBean;
import com.mrdu.bean.TestID;

import android.app.Fragment;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONException;

public class ShortEmotionFragment extends Fragment implements OnClickListener {
	private ImageView photo;
	private Questionare qn;
	private Button answerButton1;
	private Button answerButton2;
	private Button answerButton3;
	private TextView t ;
	private long starttime;
	private Handler h = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			photo.setVisibility(View.INVISIBLE);
			starttime = System.currentTimeMillis();
		}
	};
	private Handler e = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			t.setText("判断何种情绪类别");
			answerButton1.setVisibility(View.VISIBLE);
			answerButton2.setVisibility(View.VISIBLE);
			answerButton3.setVisibility(View.VISIBLE);
			qn = new Questionare(TestID.DZSB);
			qn.next();
			setQuestion(qn.getQuestion());
		}
	};
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// [1]通过打气筒把一个布局转换成view对象
		View view = inflater.inflate(R.layout.fragment_shortemotion,container,false);
		photo = (ImageView) view.findViewById(R.id.iv_photo);
		answerButton1 = (Button) view.findViewById(R.id.pre_quest);
		answerButton2 = (Button) view.findViewById(R.id.next_quest);
		answerButton3 = (Button) view.findViewById(R.id.button3);
		answerButton1.setOnClickListener(this);
		answerButton2.setOnClickListener(this);
		answerButton3.setOnClickListener(this);
		t = (TextView)view.findViewById(R.id.textView1);
		tips();
		return view;
	}
	private void tips(){
		t.setText("准备开始测试");
		answerButton1.setVisibility(View.INVISIBLE);
		answerButton2.setVisibility(View.INVISIBLE);
		answerButton3.setVisibility(View.INVISIBLE);
		int r = getResources().getIdentifier("happy2","drawable", "com.mrdu");
		photo.setImageResource(r);
		new Thread(new Runnable() {
			@Override
			public void run() {
				e.sendEmptyMessageDelayed(1, 2000);
			}

		}).start();
	}
	private void setQuestion(QuestionBean qb) {
		String src = qb.question;
		String type = "drawable";
		String packge = "com.mrdu";
		int rid = getResources().getIdentifier(src, type, packge);
		photo.setImageResource(rid);
		photo.setVisibility(View.VISIBLE);
		new Thread(new Runnable() {
			@Override
			public void run() {
				h.sendEmptyMessageDelayed(1, 25);
			}

		}).start();
	}

	@Override
	public void onClick(View v) {
		TestActivity activity = (TestActivity) this.getActivity();
		switch (v.getId()) {
		case R.id.pre_quest:
			qn.doAnswer(1);
			break;
		case R.id.next_quest:
			qn.doAnswer(2);
			break;
		case R.id.button3:
			qn.doAnswer(3);
			break;
		}
		if (qn.next()) {
			setQuestion(qn.getQuestion());
		} else {
//			try {
//				activity.onAnswer(qn.getScore(), TestID.DZSB);
//			} catch (JSONException e1) {
//				e1.printStackTrace();
//			}
		}
	}
}
