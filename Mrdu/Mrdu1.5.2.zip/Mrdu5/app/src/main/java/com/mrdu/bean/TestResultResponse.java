package com.mrdu.bean;

public class TestResultResponse {

    public int status;
    public String error;

}
