package com.mrdu;

import com.google.gson.Gson;
import com.mrdu.bean.UserBean;
import com.mrdu.net.IUserUtil;
import com.mrdu.net.MyException;
import com.mrdu.net.impl.UserUtilSQL;
import com.mrdu.view.MyBackTitleBar;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class RegistActivity extends Activity implements OnClickListener {
    private Context mContext = this;
    private EditText et_username;
    private EditText et_password;
    private Button bt_regist;
    private IUserUtil userutil;
    private MyBackTitleBar myBackTitleBar;
    UserBean ub = new UserBean();
    private OkHttpClient client = new OkHttpClient();
    public static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if (msg.what == 1) {
                String retString = (String) msg.obj;
                Log.v("regist", retString);
                UserBean userBean = UserBean.responseUser(retString);
                if (userBean != null) {
                    if (userBean.status == 201) {
                        Toast.makeText(mContext, "注册成功，请登录", Toast.LENGTH_SHORT).show();
                        RegistActivity.this.startActivity(new Intent(mContext, LoginActivity.class));
                        RegistActivity.this.finish();
                    } else if (userBean.status == 403) {
                        Toast.makeText(mContext, userBean.error, Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(mContext, "网络信号差，注册失败！", Toast.LENGTH_SHORT).show();
                }

            }
        }
    };

    private Handler successhandler = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            Toast.makeText(mContext, "注册成功，请登录", Toast.LENGTH_SHORT).show();
            RegistActivity.this.startActivity(new Intent(mContext, LoginActivity.class));
            RegistActivity.this.finish();
        }

    };

    private Handler failhandler = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            String message = (String) msg.obj;
            Toast.makeText(mContext, message, Toast.LENGTH_SHORT).show();
        }

    };

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_regist);
        // 找到控件
        myBackTitleBar = (MyBackTitleBar) findViewById(R.id.my_back_title);
        myBackTitleBar.setTitle("注册");
        et_username = (EditText) findViewById(R.id.et_username);
        et_password = (EditText) findViewById(R.id.et_password);
        bt_regist = (Button) findViewById(R.id.bt_regist);
        //userutil = new UserUtilSQL(this);
        bt_regist.setOnClickListener(this);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.bt_regist:
                // 注册按钮
                try {
                    regist();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                break;
        }
    }

    private void regist() throws JSONException {
        final String username = et_username.getText().toString().trim();
        final String password = et_password.getText().toString().trim();
        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(mContext, "学号或密码不能为空", Toast.LENGTH_SHORT).show();
            return;
        }
        ub.addUserBean(username, password);
        postRegistRequest(ub);

    }

    private void postRegistRequest(UserBean ub) throws JSONException {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("username", this.ub.username);
        jsonObject.put("password", this.ub.password);
        RequestBody requestBody = RequestBody.create(JSON, String.valueOf(jsonObject));
        final Request request = new Request.Builder()
                .url(getResources().getString(R.string.url_regist))
                .post(requestBody).build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                Log.e("yang", response.body().string());
                handler.obtainMessage(1, response.body().string()).sendToTarget();
            }
        });
    }

}
