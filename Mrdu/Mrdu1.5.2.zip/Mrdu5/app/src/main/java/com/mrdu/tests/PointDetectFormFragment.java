package com.mrdu.tests;

import java.util.Random;

import com.mrdu.R;
import com.mrdu.TestActivity;
import com.mrdu.bean.QuestionBean;
import com.mrdu.bean.TestID;

import android.app.Fragment;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

import org.json.JSONException;

public class PointDetectFormFragment extends Fragment implements
		OnClickListener {
	private Questionare qn;
	private ImageView photo1;
	private ImageView photo2;
	private ImageView photo3;
	private Button clickhere;
	private Rect happyRect;
	private Rect normalRect;
	private Rect sadRect;
	private boolean start;
	
	private long starttime; 
	private Handler h = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			clickhere.setVisibility(View.VISIBLE);
			photo1.setVisibility(View.INVISIBLE);
			photo2.setVisibility(View.INVISIBLE);
			photo3.setVisibility(View.INVISIBLE);
			starttime = System.currentTimeMillis();
		}

	};

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// [1]通过打气筒把一个布局转换成view对象
		View view = inflater.inflate(R.layout.fragment_pointdetect, container,
				false);
		photo1 = (ImageView) view.findViewById(R.id.iv_photo1);
		photo2 = (ImageView) view.findViewById(R.id.iv_photo2);
		photo3 = (ImageView) view.findViewById(R.id.iv_photo3);
		clickhere = (Button) view.findViewById(R.id.bt_clickhere);
		clickhere.setOnClickListener(this);

		clickhere.setText("开始测试");
		start = false;

		qn = new Questionare(TestID.DTCFS);
		qn.next();

		return view;
	}

	private void setQuestion(QuestionBean qb) {

		String happy = qb.answer1;
		String normal = qb.answer2;
		String sad = qb.answer3;
		String type = "drawable";
		String packge = "com.mrdu";
		
		photo1.setVisibility(View.VISIBLE);
		photo2.setVisibility(View.VISIBLE);
		photo3.setVisibility(View.VISIBLE);
		
		int happyrid = getResources().getIdentifier(happy, type, packge);
		int normalrid = getResources().getIdentifier(normal, type, packge);
		int sadrid = getResources().getIdentifier(sad, type, packge);

		photo1.setImageResource(happyrid);
		photo2.setImageResource(normalrid);
		photo3.setImageResource(sadrid);

		// 获取窗口宽高
		int ww = this.getView().getWidth();
		int wh = this.getView().getHeight();

		Random rand = new Random();

		// 获取开心图片的宽高
		Bitmap bitmap = BitmapFactory.decodeResource(this.getResources(),
				happyrid);
		int height = bitmap.getHeight();
		int width = bitmap.getWidth();

		// 准备开心Rect
		int randx = rand.nextInt(ww - width);
		int randy = rand.nextInt(wh - height);
		happyRect = new Rect(randx, randy, randx + width, randy + height);

		// 设置开心的位置

		photo1.setX(happyRect.left);
		photo1.setY(happyRect.top);

		// 获取一般图片的宽高
		bitmap = BitmapFactory.decodeResource(this.getResources(), normalrid);
		height = bitmap.getHeight();
		width = bitmap.getWidth();

		// 准备一般Rect
		do {
			randx = rand.nextInt(ww - width);
			randy = rand.nextInt(wh - height);
			normalRect = new Rect(randx, randy, randx + width, randy + height);
			// 不要与快乐相碰撞
		} while (normalRect.intersect(happyRect));

		// 设置一般的位置
		photo2.setX(normalRect.left);
		photo2.setY(normalRect.top);

		// 获取悲伤图片的宽高
		bitmap = BitmapFactory.decodeResource(this.getResources(), sadrid);
		height = bitmap.getHeight();
		width = bitmap.getWidth();

		// 准备悲伤Rect
		do {
			randx = rand.nextInt(ww - width);
			randy = rand.nextInt(wh - height);
			sadRect = new Rect(randx, randy, randx + width, randy + height);
			// 不要与快乐，悲伤相碰撞
		} while (sadRect.intersect(happyRect) || sadRect.intersect(normalRect));

		// 设置悲伤的位置

		photo3.setX(sadRect.left);
		photo3.setY(sadRect.top);

		// 设置按钮位置，不可见
		int bw = clickhere.getWidth();
		int bh = clickhere.getHeight();
		int x, y;
		clickhere.setVisibility(View.INVISIBLE);
		if (qb.question.equals("happy")) {
			x = happyRect.left
					+ rand.nextInt(happyRect.right - happyRect.left - bw);
			y = happyRect.top
					+ rand.nextInt(happyRect.bottom - happyRect.top - bh);
		} else if (qb.question.equals("normal")) {
			x = normalRect.left
					+ rand.nextInt(normalRect.right - normalRect.left - bw);
			y = normalRect.top
					+ rand.nextInt(normalRect.bottom - normalRect.top - bh);
		} else {
			x = sadRect.left + rand.nextInt(sadRect.right - sadRect.left - bw);
			y = sadRect.top + rand.nextInt(sadRect.bottom - sadRect.top - bh);
		}
		clickhere.setX(x);
		clickhere.setY(y);
		new Thread(new Runnable() {

			@Override
			public void run() {
				h.sendEmptyMessageDelayed(1, 3000);
			}

		}).start();
	}

	@Override
	public void onClick(View v) {
		if (!start) {
			setQuestion(qn.getQuestion());
			clickhere.setText("点我");
			start = true;
		} else {
			TestActivity activity = (TestActivity) this.getActivity();
			switch (v.getId()) {
			case R.id.bt_clickhere:
				long time = System.currentTimeMillis() - starttime;
				System.out.println("反应时间是！！！！！！！"+time);
				qn.doAnswer((int)time);
				break;
			}
			setQuestion(qn.getQuestion());
			
			if (qn.next()) {
				setQuestion(qn.getQuestion());
			} else {
//				try {
//					activity.onAnswer(qn.getScore(), TestID.DTCFS);
//				} catch (JSONException e) {
//					e.printStackTrace();
//				}
			}
			
		}
	}
}
