package com.mrdu.bean;

public class TestID {
	// 暂未开发
	public static final int NONE = -1;
	// 渐变范式
	public static final int JBFS = 1;
	// 点探测范式
	public static final int DTCFS = 2;
	// 问卷调查
	public static final int BECK = 3;
	//宏表情测试
	public static final int HBQCS = 4;
	//短暂识别
	public static final int DZSB = 5;
	//Stroop测试
	public static final int STROOP = 6;
	//其他量表测试
	public static final int QTLB = 7;
}
