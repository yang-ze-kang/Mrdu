package com.mrdu;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.mrdu.bean.ResultBean;
import com.mrdu.bean.TestID;
import com.mrdu.bean.UserBean;
import com.mrdu.net.IResultUtil;
import com.mrdu.net.MyException;
import com.mrdu.net.impl.ResultUtilSQL;
import com.mrdu.util.MyApplication;
import com.mrdu.view.MyBackTitleBar;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class ResultActivity extends Activity implements OnClickListener {
	IResultUtil result;
	Context mContext = this;
	Button bt_dtcfs;
	Button bt_dzsb;
	Button bt_jbfs;
	Button bt_qxmm;
	Button bt_sycs;
	Button bt_wjdc;
	//TextView textviewname;
	TextView textviewscore;
	TextView texttitle;
	//ImageView imagew1;
	WebView webview;
	double score = 0;
	List<ResultBean> wjdc = new ArrayList<ResultBean>();
	List<ResultBean> jbfs = new ArrayList<ResultBean>();
	List<ResultBean> dtcfs = new ArrayList<ResultBean>();
	int select = 3;
	private MyBackTitleBar myBackTitleBar;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_result);
		//初始化标题
		myBackTitleBar=(MyBackTitleBar)findViewById(R.id.my_back_title);
		myBackTitleBar.setTitle("结果");

		//textviewname = (TextView) findViewById(R.user_id.textView1);
		webview = (WebView)findViewById(R.id.chartshow_web);
		webview.getSettings().setAllowFileAccess(true);
		webview.getSettings().setJavaScriptEnabled(true);
		webview.loadUrl("file:///android_asset/echarts.html");
		
		textviewscore = (TextView) findViewById(R.id.textView3);
		texttitle = (TextView) findViewById(R.id.textView2);
		bt_dtcfs = (Button) findViewById(R.id.pre_quest);
		bt_dzsb = (Button) findViewById(R.id.next_quest);
		bt_jbfs = (Button) findViewById(R.id.button3);
		bt_qxmm = (Button) findViewById(R.id.button4);
		bt_sycs = (Button) findViewById(R.id.button5);
		bt_wjdc = (Button) findViewById(R.id.button6);
		//imagew1=(ImageView)findViewById(R.user_id.imageView2);
		// 设置点击事件

		bt_dtcfs.setOnClickListener(this);
		bt_dzsb.setOnClickListener(this);
		bt_jbfs.setOnClickListener(this);
		bt_qxmm.setOnClickListener(this);
		bt_sycs.setOnClickListener(this);
		bt_wjdc.setOnClickListener(this);
	//	imagew1.setOnClickListener(this);
		//double test_score = 0;
		UserBean user = new UserBean();
		MyApplication app = (MyApplication) ResultActivity.this.getApplication();
		user = app.getUser();
		//textviewname.setText(user.nickname);
		result = new ResultUtilSQL(mContext);
		List<ResultBean> resultlist = new ArrayList<ResultBean>();
		try {
			resultlist = result.getResultsById(user.user_id);
		} catch (MyException e) {
			Toast.makeText(mContext, e.getMessage(), Toast.LENGTH_SHORT).show();

		} catch (Exception ee) {
			ee.printStackTrace();

		}

		Comparator<ResultBean> cpt = new Comparator<ResultBean>() {

			@Override
			public int compare(ResultBean o1, ResultBean o2) {
				return o1.id - o2.id;
			}
		};

		for (ResultBean rb : resultlist) {
			switch (rb.tid) {
			case TestID.BECK:
				wjdc.add(rb);
				break;
			case TestID.JBFS:
				jbfs.add(rb);
				break;
			case TestID.DTCFS:
				dtcfs.add(rb);

			}
		}
		if (!wjdc.isEmpty()) {
			Collections.sort(wjdc, cpt);
			double s = wjdc.get(wjdc.size() - 1).score;
			if (s <= 10) {
				s = (100 - s);
			} else if (s <= 15 && s > 10) {
				s = (100 - (10 + 4 * (s - 10)));
			} else if (s > 15 && s <= 25) {

				s = (100 - (30 + 2 * (s - 15)));
			} else {
				s = (100 - (50 + 50.0 / (63 - 25) * (s - 25)));
			}
			score += s;
		} else {
			score += 0;
		}
		if (!jbfs.isEmpty()) {
			Collections.sort(jbfs, cpt);
			double s = jbfs.get(jbfs.size() - 1).score;
			s = 100 - (s / 3.5) * 100;
			if (s > 0) {
				score += s;
			} else {
				score += 0;
			}

		} else {
			score += 0;
		}
		if (!dtcfs.isEmpty()) {
			Collections.sort(dtcfs, cpt);
			double s = dtcfs.get(dtcfs.size() - 1).score;
			if (s <= 1) {
				s = 100 - (s * 100);
			} else {
				s = 0;
			}
			score += s;
		} else {
			score += 0;
		}
		score=score/3;
		//textviewscore.setText(test_score+ "");
		textviewscore.setText("合格\n您在共有4项测试被判定为无抑郁倾向，但仍有两项测试表现稍弱，建议您放松心情调整饮食");
	}

	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			onBackPressed();
			return true;
		case R.id.personal:
			startActivity(new Intent(mContext, PersonalActivity.class));
			return true;
		}
		return true;
	}

	public void onClick(View v) {
		String re = 0 + "";
		webview.loadUrl("file:///android_asset/echarts2.html");
		switch (v.getId()) {
		case R.id.pre_quest:
			texttitle.setText("渐变范式得分");
			if (!jbfs.isEmpty()) {
				double s = jbfs.get(jbfs.size() - 1).score;
				s = 100 - (s / 3.5) * 100;
				s=21.5;
				if (s <= 100 && s > 75) {
					re = s + "  你很健康！";
				} else if (s <= 75 && s > 60) {
					re = s + "  你有轻度的情绪不良，请注意调解！";
				} else if (s <= 60 && s > 15) {
					re = s + "  你有轻度的抑郁倾向，请即时去看心理医生！";

				} else if (s < 15) {
					re = s + "  你有严重的抑郁症，必须看心理医生接受治疗！";
				} else {
					s = 0;
					re = s + "  你有严重的抑郁症，必须看心理医生接受治疗！";
				}

			}
			textviewscore.setText(re + "");
			break;
		case R.id.next_quest:
			//Toast.makeText(mContext, "待开发", 0).show();
			texttitle.setText("短暂识别测试得分");
			textviewscore.setText("19.2"+"你有严重的抑郁症，必须看心理医生接受治疗！");
			webview.loadUrl("file:///android_asset/echarts3.html");
			break;
		case R.id.button3:
			/* Toast.makeText(mContext, "待开发", 0).show(); */
			texttitle.setText("点探测测式");
			webview.loadUrl("file:///android_asset/echarts4.html");
			if (!dtcfs.isEmpty()) {
				// String re;
				double s = dtcfs.get(dtcfs.size() - 1).score;
				if (s <= 1) {
					s = 100 - (s * 100);

					if (s <= 100 && s >= 90) {
						re = s + "  你很健康！";
					} else if (s < 90 && s >= 70) {
						re = s + "  你有轻度的情绪不良，请注意调解！";
					} else if (s < 70 && s >= 50) {
						re = s + "  你有轻度的抑郁倾向，请即时去看心理医生！";
					} else {
						re = s + "  你有严重的抑郁症，必须看心理医生接受治疗！";
					}

				} else {
					re = 0 + "  你有严重的抑郁症，必须看心理医生接受治疗！";
				}
				textviewscore.setText(re);
			}
			textviewscore.setText(re);
			textviewscore.setText("50"+"你有轻度的情绪不良，请注意调解！");
			break;
		case R.id.button4:
			//Toast.makeText(mContext, "待开发", 0).show();
			texttitle.setText("宏表情测试得分");
			textviewscore.setText("70.7"+"你有轻度的情绪不良，请注意调解！");
			webview.loadUrl("file:///android_asset/echarts5.html");
			break;
		case R.id.button5:
			//Toast.makeText(mContext, "待开发", 0).show();
			//startActivity(new Intent(mContext, TestChartActivity.class));
			texttitle.setText("Stroop测试得分");
			textviewscore.setText("41.4"+"你有严重的抑郁症，必须看心理医生接受治疗！");
			webview.loadUrl("file:///android_asset/echarts6.html");
			break;
		case R.id.button6:

			texttitle.setText("量表测试情况");
			webview.loadUrl("file:///android_asset/echarts7.html");
			if (!wjdc.isEmpty()) {
				// String re;
				re = "您通过了三项量表测试，其中汉密尔顿量表得分"+re;
				double s = wjdc.get(wjdc.size() - 1).score;
				if (s <= 10) {
					re = (100 - s) + "  你很健康！";
				} else if (s <= 15 && s > 10) {
					re = (100 - (10 + 4 * (s - 10))) + "  你有轻度的情绪不良，请注意调解！";
				} else if (s > 15 && s <= 25) {

					re = (100 - (30 + 2 * (s - 15))) + "  你有轻度的抑郁倾向，请即时去看心理医生！";
				} else {
					re = (100 - (50 + 50.0 / (63 - 25) * (s - 25))) + "  你有严重的抑郁症，必须看心理医生接受治疗！";
				}
				re = "您通过了三项量表测试，其中汉密尔顿量表得分"+"43,你有轻度的情绪不良，请注意调解！";
				textviewscore.setText(re);
			} else {
				textviewscore.setText(re);
			}
			break;
		//case R.user_id.imageView2:
			
		//	textviewscore.setText(test_score+"");
		}
	}

	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
