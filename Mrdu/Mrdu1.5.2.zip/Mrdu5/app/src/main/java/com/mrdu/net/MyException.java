package com.mrdu.net;

public class MyException extends Exception {


	/**
	 * 
	 */
	private static final long serialVersionUID = 6787602247072422591L;

	public MyException(String detailMessage) {
		super(detailMessage);
	}
	

}
